// deprecated stub (site-level): real code is in /assets/blueapi_help.js
