// CAL DATE-RANGE LABEL PATCH v3
// - فقط نمایش تاریخ روی داشبورد/HRMS و فیلترها را در مود جلالی شمسی می‌کند
// - مقدار واقعی که به سرور می‌رود دست نمی‌خورد (هنوز میلادی)
// - بدون دست‌زدن به Litepicker / DateRangePicker

(function () {
  if (window.__CAL_DATE_RANGE_LABEL_V3__) return;
  window.__CAL_DATE_RANGE_LABEL_V3__ = 1;

  function is_jalali_on() {
    try {
      if (window.CAL && typeof window.CAL.isJalali === "function") {
        return !!window.CAL.isJalali();
      }
      var m = localStorage.getItem("CAL_MODE") || "gregorian";
      return m === "jalali";
    } catch (e) {
      return false;
    }
  }

  function ensure_persian_date() {
    if (typeof window.persianDate !== "undefined") return true;
    try {
      var d = document;
      if (!d.querySelector('script[data-cal-persian-date]')) {
        var s = d.createElement("script");
        s.src = "/files/persian-date.min.js";
        s.setAttribute("data-cal-persian-date", "1");
        d.head.appendChild(s);
      }
    } catch (e) {}
    // فعلاً اگر لود نشده، false
    return typeof window.persianDate !== "undefined";
  }

  function clean_greg(g) {
    if (!g || typeof g !== "string") return null;
    var m = g.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!m) return null;
    var year = parseInt(m[1], 10);
    if (year < 1900 || year > 2200) return null; // 0000، 0002، ...
    return g;
  }

  function greg_to_jalali(g) {
    try {
      if (!g) return "";
      if (typeof window.persianDate === "undefined") return g;
      var iso = g.replace(" ", "T");
      var d = new Date(iso);
      if (isNaN(d.getTime())) return g;
      return new persianDate(d).format("YYYY/MM/DD");
    } catch (e) {
      return g;
    }
  }

  // ورودی: متن کامل؛ خروجی: متن جدید یا null اگر نباید تغییر کند
  function convert_text(txt) {
    if (!txt) return null;
    txt = String(txt).trim();
    if (!txt) return null;

    // حالت رنج: YYYY-MM-DD ... YYYY-MM-DD
    var re_range = /(\d{4}-\d{2}-\d{2}).*?(\d{4}-\d{2}-\d{2})/;
    var m = txt.match(re_range);
    if (m) {
      var g1 = clean_greg(m[1]);
      var g2 = clean_greg(m[2]);

      if (!g1 && !g2) {
        return "انتخاب بازهٔ تاریخ";
      }

      var j1 = g1 ? greg_to_jalali(g1) : "";
      var j2 = g2 ? greg_to_jalali(g2) : "";

      if (j1 && j2) return j1 + " تا " + j2;
      if (j1) return j1;
      if (j2) return j2;
      return "انتخاب بازهٔ تاریخ";
    }

    // حالت فقط یک تاریخ خالی: "YYYY-MM-DD" به‌تنهایی
    var single = txt.match(/^(\d{4}-\d{2}-\d{2})$/);
    if (single) {
      var g = clean_greg(single[1]);
      if (!g) return "انتخاب بازهٔ تاریخ";
      return greg_to_jalali(g);
    }

    return null;
  }

  function scan_once() {
    if (!is_jalali_on()) return;
    if (!ensure_persian_date()) return;

    try {
      var nodes = document.querySelectorAll("button, span, div");
      for (var i = 0; i < nodes.length; i++) {
        var el = nodes[i];
        var txt = (el.textContent || "").trim();
        if (!txt) continue;
        // سریع ردشو اگر نه تاریخ دارد نه "انتخاب بازهٔ تاریخ"
        if (txt.indexOf("انتخاب بازهٔ تاریخ") === -1 &&
            !/\d{4}-\d{2}-\d{2}/.test(txt)) {
          continue;
        }
        var new_txt = convert_text(txt);
        if (new_txt && new_txt !== txt) {
          el.textContent = new_txt;
        }
      }
    } catch (e) {
      // سکوت برای جلوگیری از کرش Desk
    }
  }

  try {
    console.log("CAL date-range label v3 loaded.");
  } catch (e) {}

  setInterval(function () {
    try {
      scan_once();
    } catch (e) {}
  }, 1500);
})();
