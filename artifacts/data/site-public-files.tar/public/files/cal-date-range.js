// CAL DATE-RANGE :: safe stub (disabled)
// فعلاً هیچ تغییری روی DateRange داشبورد / چارت‌ها انجام نمی‌دهد.
(function () {
  try {
    console.log("CAL date-range stub loaded (disabled).");
  } catch (e) {}
})();
